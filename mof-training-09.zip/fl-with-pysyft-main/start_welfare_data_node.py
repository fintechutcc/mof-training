import argparse
import torch
from syft.workers.websocket_server import WebsocketServerWorker
import syft as sy
import pandas as pd 
import numpy as np 
from sklearn.preprocessing import StandardScaler

# Arguments
parser = argparse.ArgumentParser(description="Run websocket server worker.")
parser.add_argument(
    "--port", "-p", type=int, help="port number of the websocket server worker, e.g. --port 8777"
)
parser.add_argument("--host", type=str, default="10.7.3.34", help="host for the connection")
parser.add_argument(
    "--id", type=str, help="name (id) of the websocket server worker, e.g. --id alice"
)
parser.add_argument(
    "--verbose",
    "-v",
    action="store_true",
    help="if set, websocket server worker will be started in verbose mode",
)


def main(**kwargs):  # pragma: no cover
    """Helper function for spinning up a websocket participant."""

    # Create websocket worker
    worker = WebsocketServerWorker(**kwargs)

    # Set up data
    df = pd.read_csv('data/data_welfare.csv')
    X_Columns = ['Age', 'Owner_Income']
    X = df[X_Columns]
    X = X.astype(np.float)
    
    y = df['Label']
    y = y.astype(np.float)

    ss = StandardScaler()
    ss.fit(X)
    X_std = ss.transform(X)

    #X = [[0.0, 1.0], [1.0, 0.0], [1.0, 1.0], [0.0, 0.0]]
    data   = torch.tensor(X_std, dtype=torch.float32, requires_grad=True)
    target = torch.tensor(y.values, dtype=torch.float32, requires_grad=False)

    # Create a dataset using the toy data
    dataset = sy.BaseDataset(data, target)

    # Tell the worker about the dataset
    worker.add_dataset(dataset, key="welfare")

    # Start worker
    worker.start()

    return worker


if __name__ == "__main__":
    hook = sy.TorchHook(torch)

    args = parser.parse_args()
    kwargs = {
        "id": args.id,
        "host": args.host,
        "port": args.port,
        "hook": hook,
        "verbose": args.verbose,
    }

    main(**kwargs)
