# Federated Learning with PySyft
Here was a project we introduced to MoF. Based on PySyft, the Federated Learning was implemented. There are three main files as following:

1. Aggregator_Node.ipynb: A Jupyter notebook file for Aggregator Node.
2. Data_Node.ipynb: A Jupyter notebook file for data exploration in Data Node.
3. run_welfare_data_node.sh: A shell script to run Data_Node.
